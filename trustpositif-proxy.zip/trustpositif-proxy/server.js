import express from "express";
import puppeteer from "puppeteer";

const app = express();
const PORT = process.env.PORT || 3000;

app.get("/check", async (req, res) => {
  const domain = req.query.domain;
  if (!domain) return res.status(400).json({ error: "Parameter domain wajib diisi" });

  const url = "https://trustpositif.komdigi.go.id/";

  try {
    const browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    const page = await browser.newPage();
    await page.goto(url, { waitUntil: "domcontentloaded", timeout: 60000 });

    // ketik domain ke kolom pencarian
    await page.type("#url-search", domain);
    await page.keyboard.press("Enter");

    // tunggu hasil muncul
    await page.waitForTimeout(5000);
    const content = await page.content();

    const status = content.toLowerCase().includes(domain.toLowerCase())
      ? "ADA"
      : "TIDAK ADA";

    await browser.close();

    res.json({ domain, status });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.listen(PORT, () => {
  console.log(`Proxy TrustPositif berjalan di port ${PORT}`);
});
